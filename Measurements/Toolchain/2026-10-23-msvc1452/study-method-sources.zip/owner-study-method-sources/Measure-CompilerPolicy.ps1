[CmdletBinding()]
param([Parameter(Mandatory)][ValidateSet('DxUi','RedXe','RedSalamander','RedPrism','RedTilde')][string]$Repository,[ValidateRange(2,16)][int]$Blocks=12,[switch]$DiagnosticSharedHost)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
. 'E:\DxUi.Perf\CompilerStudyBuildActivity.ps1'
# Foreground retries are an explicit prerequisite of the paired study, never a concurrent workload.
$foregroundPending='E:\DxUi.Perf\compiler-policy-completion\approved-interactive.pending'
while(Test-Path -LiteralPath $foregroundPending){Start-Sleep -Seconds 5}
$root="E:\$Repository.Perf\msvc1452"
$frozen="E:\$Repository.Perf\msvc1452-frozen"
$run="E:\$Repository.Perf\compiler-policy-study\"+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmss')+'-'+[guid]::NewGuid().ToString('N')
[void][IO.Directory]::CreateDirectory($run)
$activity=@(Get-CompilerStudyBuildActivity)
if(@($activity|Where-Object {-not $_.activeValidationCoordinator}).Count-and -not $DiagnosticSharedHost){throw "Native compilation is active; study not started. Empty reserved directory retained: $run"}
if(@($activity|Where-Object activeValidationCoordinator).Count){$DiagnosticSharedHost=[switch]$true;Write-Warning 'Another native validation coordinator is active; this study is explicitly diagnostic shared-host evidence.'}
if($Repository-eq 'RedTilde'){Import-Module (Join-Path $root 'Build/Performance.psm1') -Force}
function Median([double[]]$Values){$s=@($Values|Sort-Object);$m=[int][math]::Floor($s.Count/2);if($s.Count%2){return $s[$m]};return ($s[$m-1]+$s[$m])/2}
$nativeChanges=@(& git -C $root diff HEAD --name-only -- '*.cpp' '*.h' '*.hpp' '*.inl' '*.hlsl')
if($nativeChanges.Count){throw 'Native source changed; this flag-only study requires a new design.'}
function Assert-FrozenClosures {
    $identities=[ordered]@{}
    foreach($side in 'baseline','candidate'){
        $manifestPath=Join-Path $frozen ($side+'-manifest.json')
        $manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json
        if($manifest.repository-cne $Repository-or $manifest.side-cne $side){throw 'Frozen closure manifest identity mismatch.'}
        foreach($file in $manifest.files){
            $filePath=Join-Path (Join-Path $frozen $side) $file.path
            if((Get-Item -LiteralPath $filePath).Length-ne $file.bytes-or (Get-FileHash -LiteralPath $filePath).Hash-cne $file.sha256){throw "Frozen runtime closure changed: $filePath"}
        }
        $identities[$side]=[ordered]@{manifestSha256=(Get-FileHash -LiteralPath $manifestPath).Hash;files=$manifest.files.Count;sourceCommit=$manifest.sourceCommit}
    }
    return $identities
}
$closureIdentities=Assert-FrozenClosures
$plan=[ordered]@{closureIdentities=$closureIdentities;repository=$Repository;harnessSha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash;activityHelperSha256=(Get-FileHash -LiteralPath 'E:\DxUi.Perf\CompilerStudyBuildActivity.ps1').Hash;createdUtc=[DateTime]::UtcNow.ToString('o');blocks=$Blocks;order='ABBA for even blocks, BAAB for odd blocks';warmups='one A and B per scenario, retained but excluded from summaries';compiler='14.52.37025';baselinePolicy='retained original Release policy';candidatePolicy='Gy-REF-GL-LTCG-full-v1';nativeSourceChanges=$nativeChanges;initialBuildActivity=$activity;diagnosticSharedHost=[bool]$DiagnosticSharedHost;powerScheme=(& powercfg /getactivescheme)-join ' ';sourceHead=(& git -C $root rev-parse HEAD).Trim();activityObservation='Before/after every sample plus two-second polling while the owned benchmark process runs; active native MSBuild parents included.';scope='Compiler-policy experiment on frozen original/candidate runtime closures; not ordinary identical-profile evidence reuse or a compiler-version speedup.'}
$plan|ConvertTo-Json -Depth 5|Set-Content (Join-Path $run 'plan.json')
$samples=[Collections.Generic.List[object]]::new()
$fixtureIdentities=@{}
$scenarios=@(if($Repository-eq 'RedTilde'){@('Compose','Split')}else{@('Default')})
$vswhere=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
$vs=(& $vswhere -latest -prerelease -products '*' -requires Microsoft.Component.MSBuild -property installationPath).Trim()
function Sample([string]$Side,[string]$Scenario,[int]$Block,[string]$Position){
    $directory=Join-Path $run "$Scenario-$Block-$Position-$Side"
    [void][IO.Directory]::CreateDirectory($directory)
    $closure=Join-Path $frozen $Side
    $native=Join-Path $directory 'native.json'
    $exeName=switch($Repository){DxUi{'DxUi.EmbeddedTests.exe'};RedXe{'SystemDataTests.exe'};RedPrism{'RedPrism.exe'};RedTilde{'RedTilde.exe'};RedSalamander{'PerformanceTests2.dll'}}
    $artifact=Join-Path $closure $exeName
    $hash=(Get-FileHash -LiteralPath $artifact).Hash
    $exe=if($Repository-eq 'RedSalamander'){Join-Path $vs 'Common7/IDE/CommonExtensions/Microsoft/TestWindow/vstest.console.exe'}else{$artifact}
    $arguments=switch($Repository){
        DxUi{@('--benchmark',$native)}
        RedXe{@('--benchmark')}
        RedPrism{@('--warp','--bench','ui-sampler','--isa','scalar')}
        RedTilde{@('--performance-probe',$native,'--document',(Join-Path $root 'docs/examples/s5-performance.md'),'--scenario',$Scenario.ToLowerInvariant(),'--cycles','16','--warp','--data-dir',(Join-Path $directory 'data'))}
        RedSalamander{@($artifact,'/Platform:x64','/TestCaseFilter:FullyQualifiedName~LargeFolderIconEnumeration',('/ResultsDirectory:'+$directory),'/Logger:trx;LogFileName=native.trx')}
    }
    $start=[Diagnostics.ProcessStartInfo]::new($exe);$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.WorkingDirectory=$closure
    $start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
    foreach($argument in $arguments){$start.ArgumentList.Add($argument)}
    if($Repository-eq 'RedSalamander'){$start.Environment['REDSALAMANDER_TEST_ROOT']='E:\RedSalamander.Perf'}
    $p=[Diagnostics.Process]::new();$p.StartInfo=$start
    $watch=[Diagnostics.Stopwatch]::StartNew();$code=-1;$cpu=$null;$peak=$null
    $before=@(Get-CompilerStudyBuildActivity)
    try{
        [void]$p.Start();$stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
        $observedDuring=[Collections.Generic.List[object]]::new()
        $processDeadline=[Diagnostics.Stopwatch]::StartNew()
        while(-not $p.WaitForExit(2000)){
            foreach($active in @(Get-CompilerStudyBuildActivity)){$observedDuring.Add($active)}
            if($processDeadline.Elapsed.TotalSeconds-ge 180){$p.Kill($true);$p.WaitForExit();$code=124;break}
        }
        if($code-ne 124){$code=$p.ExitCode}
        $observedAfter=@(Get-CompilerStudyBuildActivity)
        $watch.Stop()
        $out=$stdout.GetAwaiter().GetResult();$err=$stderr.GetAwaiter().GetResult()
        [IO.File]::WriteAllText((Join-Path $directory 'stdout.log'),$out);[IO.File]::WriteAllText((Join-Path $directory 'stderr.log'),$err)
        try{$cpu=$p.TotalProcessorTime.TotalMilliseconds;$peak=$p.PeakWorkingSet64}catch{$cpu=$null;$peak=$null}
    }finally{$p.Dispose()}
    $receipt=[ordered]@{repository=$Repository;scenario=$Scenario;block=$Block;position=$Position;side=$Side;executable=$exe;arguments=@($arguments);artifact=$artifact;artifactSha256=$hash;exitCode=$code;elapsedMs=$watch.Elapsed.TotalMilliseconds;commandProcessCpuMs=$cpu;commandProcessPeakWorkingSetBytes=$peak;preBuildActivity=$before;duringBuildActivity=@($observedDuring.ToArray()|Sort-Object ProcessName,Id -Unique);postBuildActivity=$observedAfter;metrics=[ordered]@{};path=$directory}
    $receipt|ConvertTo-Json -Depth 7|Set-Content (Join-Path $directory 'receipt.json')
    if($code-ne 0){throw "Native benchmark failed: $directory, exit $code"}
    if($hash-cne (Get-FileHash -LiteralPath $artifact).Hash){throw 'Frozen executable mutated during measurement.'}
    $metrics=$receipt.metrics
    switch($Repository){
        DxUi{
            $v=Get-Content $native -Raw|ConvertFrom-Json
            if($v.fixture-cne 'dxui-complex-ui-v2'-or $v.renderer-cne 'WARP'-or $v.roundCount-ne 5-or $v.controls-ne 83-or $v.width-ne 1280-or $v.height-ne 720-or $v.dpi-ne 96){throw 'DxUi fixture changed.'}
            foreach($phase in $v.scenarios){$metrics[$phase.name+'FrameP50Ms']=Median @($phase.rounds.frameP50Ms);$metrics[$phase.name+'PrivateBytes']=Median @($phase.rounds.privateBytes)}
        }
        RedXe{
            $line=$out-split "`n"|Where-Object {$_-like 'SystemData Release row-cap measurement:*'}
            if(@($line).Count-ne 1){throw 'Missing SystemData benchmark measurement.'}
            $values=@{};foreach($m in [regex]::Matches($line,'([a-z_]+)=([0-9.eE+-]+)')){$values[$m.Groups[1].Value]=[double]::Parse($m.Groups[2].Value,[Globalization.CultureInfo]::InvariantCulture)}
            if($values.rows-ne 2048-or $values.collections-ne 2-or $values.cpu_probe_collections-ne 64){throw 'SystemData fixture changed.'}
            $metrics.wallUsPerCollection=$values.wall_us_per_collection;$metrics.cpuUsPerCollection=$values.process_cpu_us_per_collection
            $receipt.nativeResourceDiagnostics=$values
        }
        RedPrism{
            if($out-notmatch 'UI BENCH REPORT status=ok.*smokeCorrectnessOnly=0'){throw 'Full UI benchmark receipt missing or smoke-only.'}
            $line=$out-split "`n"|Where-Object {$_-like 'UI BENCH name=sampler-accepted-prefix *'}
            if(@($line).Count-ne 1-or $line-notmatch 'width=3840 height=2160 runs=10 warmup=1 '-or $out-notmatch 'fixtureChecksum=04c311cabfc8b925'){throw 'Sampler benchmark fixture changed.'}
            $m=[regex]::Match($line,'elapsedMedianUs=([0-9.]+)');if(-not $m.Success){throw 'Sampler duration missing.'}
            $metrics.elapsedMedianUs=[double]::Parse($m.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture)
            if($peak-gt 0){$metrics.processPeakWorkingSetBytes=$peak}
        }
        RedTilde{
            $v=Get-Content $native -Raw|ConvertFrom-Json;$values=Get-RedTildePerformanceMetrics $v
            foreach($key in 'commandUs','ownerCpuCycles','completedEditUs','cleanCompletedUs','privateBytes','workingSetBytes'){$metrics[$key]=$values[$key]}
            $receipt.fixture=[ordered]@{fixture=$v.fixture;view=$v.view;widthPx=$v.widthPx;heightPx=$v.heightPx;dpi=$v.dpi;sourceUnits=$v.sourceUnits;cycles=$v.cycles;renderer=$v.renderer}
            if($v.fixture-cne 'redtilde-completed-native-v2'-or $v.view-cne $Scenario-or $v.renderer-cne 'WARP'-or $v.cycles-ne 16-or $v.sourceUnits-ne 693){throw 'RedTilde fixture changed.'}
            $fixtureText=$receipt.fixture|ConvertTo-Json -Compress
            if($fixtureIdentities.ContainsKey($Scenario)-and $fixtureIdentities[$Scenario]-cne $fixtureText){throw 'RedTilde geometry/DPI/fixture changed within the comparison.'}
            $fixtureIdentities[$Scenario]=$fixtureText
            $receipt.fixtureDocumentSha256=(Get-FileHash -LiteralPath (Join-Path $root 'docs/examples/s5-performance.md')).Hash
        }
        RedSalamander{
            [xml]$v=Get-Content (Join-Path $directory 'native.trx') -Raw
            $results=@($v.SelectNodes('//*[local-name()="UnitTestResult"]'))
            if($results.Count-ne 2-or @($results|Where-Object outcome -ne 'Passed').Count){throw 'Icon enumeration fixture did not pass both tests.'}
            foreach($result in $results){$metrics[$result.testName+'Ms']=[TimeSpan]::Parse($result.duration,[Globalization.CultureInfo]::InvariantCulture).TotalMilliseconds}
        }
    }
    $receipt|ConvertTo-Json -Depth 8|Set-Content (Join-Path $directory 'receipt.json')
    $samples.Add($receipt)
    $samples|ConvertTo-Json -Depth 9|Set-Content (Join-Path $run 'samples.json')
    Write-Host "$Repository $Scenario block=$Block $Position $Side passed"
}
foreach($scenario in $scenarios){
    Sample baseline $scenario -1 warmA;Sample candidate $scenario -1 warmB
    for($block=0;$block-lt $Blocks;$block++){$order=if($block%2-eq 0){'ABBA'}else{'BAAB'};$counts=@{A=0;B=0};foreach($label in $order.ToCharArray()){$key=[string]$label;++$counts[$key];$side=if($key-eq 'A'){'baseline'}else{'candidate'};Sample $side $scenario $block ($key+$counts[$key])}}
}
$expectedSamples=(4*$Blocks+2)*$scenarios.Count
if($scenarios.Count-ne $(if($Repository-eq 'RedTilde'){2}else{1})-or $samples.Count-ne $expectedSamples){throw 'Native sample/scenario inventory is incomplete; refusing a completed receipt.'}
if((Get-FileHash -LiteralPath $PSCommandPath).Hash-cne $plan.harnessSha256-or (Get-FileHash -LiteralPath 'E:\DxUi.Perf\CompilerStudyBuildActivity.ps1').Hash-cne $plan.activityHelperSha256){throw 'Measurement harness/observer changed during this study; retain and repeat.'}
if($Repository-eq 'RedTilde'-and @($samples.fixtureDocumentSha256|Sort-Object -Unique).Count-ne 1){throw 'Document fixture changed during the comparison.'}
if(((& powercfg /getactivescheme)-join ' ')-cne $plan.powerScheme){throw 'Power scheme changed during the study.'}
$finalClosureIdentities=Assert-FrozenClosures
if(($closureIdentities|ConvertTo-Json -Compress)-cne ($finalClosureIdentities|ConvertTo-Json -Compress)){throw 'Frozen manifests changed during study.'}
[IO.File]::WriteAllText((Join-Path $run 'complete.json'),([ordered]@{closureVerified=$true;harnessVerified=$true;expectedSampleCount=$expectedSamples;passed=$true;completedUtc=[DateTime]::UtcNow.ToString('o');sampleCount=$samples.Count;diagnosticSharedHost=[bool]$DiagnosticSharedHost}|ConvertTo-Json))
Write-Output "Completed study: $run"