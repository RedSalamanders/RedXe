function Get-CompilerStudyBuildActivity {
    $processes=@(Get-CimInstance Win32_Process -Filter "Name='cl.exe' OR Name='link.exe' OR Name='ninja.exe' OR Name='MSBuild.exe' OR Name='pwsh.exe' OR Name='powershell.exe'")
    foreach($process in $processes){
        $native=$process.Name-in @('cl.exe','link.exe','ninja.exe')
        $mainBuild=$process.Name-eq 'MSBuild.exe'-and $process.CommandLine-notmatch '(?i)/nodemode:'-and $process.CommandLine-match '(?i)\.(sln|vcxproj)(?:\s|"|$)'-and $process.CommandLine-notmatch '(?i)[-/](getItem|getProperty):'
        $fileArgument=[regex]::Match([string]$process.CommandLine,'(?i)\s-File\s+(?:"(?<file>[^"]+)"|(?<file>\S+))')
        $scriptName=if($fileArgument.Success){[IO.Path]::GetFileName($fileArgument.Groups['file'].Value.Replace('/','\'))}else{''}
        $validation=$process.Name-in @('pwsh.exe','powershell.exe')-and $scriptName-in @('Run-AllTests.ps1','test.ps1','Test-Changes.ps1')
        if($native-or $mainBuild-or $validation){[pscustomobject]@{ProcessName=$process.Name;Id=$process.ProcessId;ParentId=$process.ParentProcessId;activeNativeBuildParent=[bool]$mainBuild;activeValidationCoordinator=[bool]$validation}}
    }
}